package ru.eit.ps_java.eugenBorisov.lesson5.salary;

public interface WorkerSourceSamples {
    String[] nameSample = new String[] {"Иван", "Петр", "Марк", "Федор"},
            surnameSample = new String[] {"Иванович", "Дмитриевич", "Васильевич"},
            familySample = new String[] {"Иванов", "Петров", "Сидоров"};

}
