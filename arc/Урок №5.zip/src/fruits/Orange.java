package fruits;

public class Orange extends FruitBase implements Fruits{
    @Override
    public void setFruitName() {
        name = "Апельсин";
    }

    @Override
    public void setFruitColor() {
        color = "Оранжевый";
    }

    @Override
    public void setFruitWeight(float w) {
        weight = w;
    }
}
