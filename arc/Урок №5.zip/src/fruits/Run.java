package fruits;

public class Run {
    public static void main(String[] args) {
        var apple = new Apple();
        apple.setFruitColor();
        apple.setFruitName();
        apple.setFruitWeight(0.5f);
        apple.showInfo();
    }
}
