package fruits;

public class Apple extends FruitBase implements Fruits{
    @Override
    public void setFruitName() {
        name = "Яблоко";
    }

    @Override
    public void setFruitColor() {
        color = "Зеленое";
    }

    @Override
    public void setFruitWeight(float w) {
        weight = w;
    }
}
