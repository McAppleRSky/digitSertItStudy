package fruits;

public interface Fruits {
    void setFruitName();
    void setFruitColor();
    void setFruitWeight(float w);
}