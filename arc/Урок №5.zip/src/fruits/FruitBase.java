package fruits;

public class FruitBase {
    String name = "";
    String color = "";
    float weight = 0f;

    public void showInfo(){
        System.out.println("Название фрукта "+name + "\nЦвет: "+color + "\nВес "+weight);
    }
}
