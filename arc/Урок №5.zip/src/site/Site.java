package site;

public class Site {
    private String title = "Сайт";
    void content(){
        System.out.println("Контент сайта");
    }

    void render(Template t){

        t.header(title);
        this.content();
        t.footer(title);
    }
}
