package site;

public class Car {
    private String name;
    private int price;

    public Car(String name,int price){
        this.name = name;
        this.price = price;
    }

     void test(){
        System.out.println("Тестовый метод из Car");
    }

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }

    public void show(){
        System.out.println("Автомобиль "+name + " стоит "+price);
    }
}

