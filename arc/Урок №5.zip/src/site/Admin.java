package site;

public class Admin {
    private String title = "Админка";
    void content(){
        System.out.println("Контент админки");
    }

    void render(Template t){
        t.header(title);
        this.content();
        t.footer(title);
    }


}
