package site;

public class Run {
    public static void main(String[] args) {
        var t = new Template();
        new Admin().render(t);
        new Site().render(t);
    }
}
