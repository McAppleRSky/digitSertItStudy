package site;

public class Template {
    void header(String title){
        System.out.println("Шапка для структуры "+title);
    }
    void footer(String title){
        System.out.println("Подвал для структуры "+title);
    }
}
