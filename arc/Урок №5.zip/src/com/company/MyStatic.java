package com.company;
//Стические свойства привязаны к имени класса
//Нестатические привязаны к объекту класса
public class MyStatic {
    static int x;
    //this в static методах строго запрщен!
    static void setX(int x){
        MyStatic.x = x;
    }

    static void testStatic(int x){
        MyStatic obj = new MyStatic();
        obj.usually(x);
    }

    void usually(int x){
        MyStatic.setX(x);
    }

    public static void main(String[] args) {

    }
}
