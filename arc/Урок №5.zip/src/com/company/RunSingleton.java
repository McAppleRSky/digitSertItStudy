package com.company;

public class RunSingleton {
    static TestSingleton db;
    RunSingleton(){
        RunSingleton.db = TestSingleton.getObect();
    }

    static void showGoods(){
        db.select();
        db.insert();
    }
}
