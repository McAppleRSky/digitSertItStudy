package com.company;

public class MyStatic2 {

    int x = 10;

    int f(){
        return ++x;
    }

    public static void main(String[] args) {
        var o1 = new MyStatic2();
        var o2 = new MyStatic2();
        System.out.println(o1.f());
        System.out.println(o1.f());
        System.out.println(o2.f());
        System.out.println(o2.f());
    }
}
