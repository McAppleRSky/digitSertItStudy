package com.company;

public class DemoParams {
    void show(TestParam obj){
        System.out.println(obj.getName());
    }

    public static void main(String[] args) {
        var o = new TestParam();
        new DemoParams().show(o);
    }
}
