package com.company;

public class TestSingleton {
    private static TestSingleton obj = null;

    private TestSingleton(){
//        var connect = ...//Соединение с базой данных
    }

    public static TestSingleton getObect(){
        if(obj == null){
            obj = new TestSingleton();
        }
        return obj;
    }

    public void select(){}
    public void insert(){}
    public void update(){}
    public void delete(){}
}
