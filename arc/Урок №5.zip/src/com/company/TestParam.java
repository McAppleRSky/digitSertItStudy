package com.company;

public class TestParam {
    private String name = "Ivan";

    public String getName() {
        return name;
    }
}
