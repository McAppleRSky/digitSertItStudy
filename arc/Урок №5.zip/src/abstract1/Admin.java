package abstract1;

public class Admin extends Template {

    @Override
    String content() {
       return "Контен для админки";
    }
}
