package abstract1;

public class Site extends Template{

    @Override
    String content() {
        return "Контен для сайта";
    }
}
