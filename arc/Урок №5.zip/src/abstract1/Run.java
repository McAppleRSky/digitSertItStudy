package abstract1;

public class Run {
    public static void main(String[] args) {

        System.out.println(new Admin().render());
        System.out.println(new Site().render());
    }
}
