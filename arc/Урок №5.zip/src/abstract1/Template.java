package abstract1;

abstract public class Template {
    String header(){
       return "Шапка для структуры";
    }
    String footer(){
        return "Подвал для структуры ";
    }

    String render(){
        return header() + "\n" +content() + "\n" + footer();
    }


    abstract String content();
}
