package inheritance;

import site.Car;

public class RaceCar extends Car {
    private int speed;

    public RaceCar(String name, int price,int speed) {
        super(name, price);
        this.speed = speed;
    }

    @Override
    public void show() {
      // test();
       System.out.println("Автомобиль "+getName() + " разгоняется до скорости "+speed);
       super.show();
    }

    public static void main(String[] args) {
        var rc = new RaceCar("Ferrari", 5000,600);
        rc.show();
    }

}
