package main;

public class Man {
    public void go(){
        System.out.println("Свойство ходить");
    }
    public void eat(){
        System.out.println("Свойство eat");
    }
}
