package ru.eit.ps_java.eugenBorisov.lesson2.calc.extended.operations;

import ru.eit.ps_java.eugenBorisov.lesson2.calc.extended.type.plain.Result;

public class Div extends AbstractOperation {

    public Div() {
        objectId = "/";
    }

    @Override
    public Result mainMethod(Object... argument) {
        float first = (int)argument[0];
        for (int i = 1;i<argument.length;i++) first /= (int)argument[i];
        return new Result( Float.valueOf(first) );
    }

    @Override
    public String getObjectId() {
        return objectId;
    }

}
