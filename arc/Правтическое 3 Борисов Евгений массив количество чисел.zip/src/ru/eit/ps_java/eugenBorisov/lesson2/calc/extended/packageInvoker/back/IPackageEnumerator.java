package ru.eit.ps_java.eugenBorisov.lesson2.calc.extended.packageInvoker.back;

public interface IPackageEnumerator {

    public Object mainMethod(Object... argument);
    public String getObjectId();

}
