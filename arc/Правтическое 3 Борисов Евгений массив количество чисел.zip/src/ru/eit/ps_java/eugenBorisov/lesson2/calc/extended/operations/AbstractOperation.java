package ru.eit.ps_java.eugenBorisov.lesson2.calc.extended.operations;

import ru.eit.ps_java.eugenBorisov.lesson2.calc.extended.packageInvoker.PackageEnumerator;

public abstract class AbstractOperation extends PackageEnumerator {

}
