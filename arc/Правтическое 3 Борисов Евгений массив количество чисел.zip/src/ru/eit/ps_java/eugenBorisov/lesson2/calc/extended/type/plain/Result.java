package ru.eit.ps_java.eugenBorisov.lesson2.calc.extended.type.plain;

public class Result{

    private Object result;

    public Result(Object result) {
        this.result = result;
    }

    public Object getResult() {
        return result;
    }
}
