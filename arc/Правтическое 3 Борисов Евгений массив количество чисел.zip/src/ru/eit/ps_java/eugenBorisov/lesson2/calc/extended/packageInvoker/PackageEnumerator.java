package ru.eit.ps_java.eugenBorisov.lesson2.calc.extended.packageInvoker;

import ru.eit.ps_java.eugenBorisov.lesson2.calc.extended.packageInvoker.back.IPackageEnumerator;

public abstract class PackageEnumerator implements IPackageEnumerator {

    protected String objectId;

}
